# Design references and motion

Dynamic 0.6.1 uses a chunky digital clock and a composition that makes room for
context. It is an independent watchface by Xef. Pebble's watchfaces, plugin
examples and design guidance inform its visual language; Dynamic owns its
layout, type choices and transitions.

## Identified activity cards in 0.10.0

Every activity uses an app identity, a recognizable image and current content.
The primary image occupies 40×40 at the card’s top left; its app name uses 20px
text and its main value or 24px text follows beside it. Complete scalar values
and units can use the full width below the image. Rest, ETA and other meaningful
roles remain visible. Related support uses 16px text inside the primary card.

The optional secondary has a divider at y176, a 20px image, a 14px app name and
16px current content. Cached public content places explicit 11px “Last reported
… ago” beside its identity when both fit. The whole band yields if essential
primary content, complete values or readable identity cannot coexist. It never
becomes an anonymous footer or reuses a supporting metric as another activity.

The phone supplies app display metadata and 40px fallback hourglass, note or
generic symbol after source-revision validation. Native drawing tints a single
opaque image color to the watch foreground; multicolor album art keeps its
palette. Static hourglass artwork identifies Timer without inventing progress.
The ACT2 caption carries the projected app identity; item labels retain metric
roles. No source property, reserved native byte or alarm state is repurposed.

Canonical Music follows these same cards and Dynamic’s saved provider order.
The older standalone Music composition described below remains a compatibility
fallback. The 20 embedded presets now capture canonical Music; separate activity
fixtures retain legacy fallback coverage. Dynamic’s settings own ordering and
visibility; the shared library’s pure selector owns no preference storage.

## First-party references

| Reference | Principle carried into Dynamic |
| --- | --- |
| Kickstart | Distinctive time typography, recognizable symbols and graphics tied to real data |
| TicToc | A clear visual identity that stays recognizable when the available area changes |
| Kickstarter clock example | The same clock shapes move and scale through a transformation, then settle |
| Weather Face plugin demo | Bold hierarchy, a prominent condition image and compact groups of related values |
| Complication Face plugin demo | Two horizontal readings, rounded symbols and gauges for meaningful numeric ranges |
| Weather and Workout apps | Readable hierarchy, deliberate alignment and restrained use of color |

The PebbleOS source references are pinned to
[`7bf58aca187860b122d7ef4f7dba287d24aa887f`](https://github.com/coredevices/PebbleOS/tree/7bf58aca187860b122d7ef4f7dba287d24aa887f).
The plugin examples are pinned to
[`0e348c2a07da0642c8ac3be5a161b9a999938841`](https://github.com/coredevices/pebble-apps/tree/0e348c2a07da0642c8ac3be5a161b9a999938841).
Their source and reference images were used for design research. Reference
images are not redistributed as Dynamic assets.

Sources:

- [Kickstart](https://github.com/coredevices/PebbleOS/blob/7bf58aca187860b122d7ef4f7dba287d24aa887f/fw/apps/watch/kickstart/kickstart.c)
- [TicToc](https://github.com/coredevices/PebbleOS/blob/7bf58aca187860b122d7ef4f7dba287d24aa887f/fw/apps/watch/tictoc/default/tictoc_default.c)
- [Official historical Kickstarter clock example](https://github.com/pebble-examples/ks-clock-face)
- [Weather Face renderer](https://github.com/coredevices/pebble-apps/blob/0e348c2a07da0642c8ac3be5a161b9a999938841/weather-face/src/c/main.c)
- [Complication Face renderer](https://github.com/coredevices/pebble-apps/blob/0e348c2a07da0642c8ac3be5a161b9a999938841/complication-face/src/c/main.c)
- [Pebble UI design guidance](https://developer.repebble.com/guides/design-and-interaction/recommended/)
- [Eric Migicovsky on PebbleOS's design identity](https://ericmigi.com/blog/how-to-build-a-smartwatch-software-setting-expectations-and-roadmap/)

The plugin demos are visual and data-source references. Their renderers
primarily redraw as data arrives. Dynamic adds its own coordinated layout
transitions and retains the first two global choices in their left/right
positions. The Complication Face demo selects slots by data shape.

## Dynamic's interpretation

- **One recognizable clock:** Fredoka outlines give the time its rounded
  character. The same shapes scale and move between the large idle clock and
  compact contextual clock. Temperature and percent units share that style.
- **One canvas:** Roboto Condensed text, two horizontal readings and rounded
  symbols share the page. The date remains plain. Ordinary content uses the
  accent; amber is reserved for low-battery/connection warnings.
- **Literal information:** Temperature, Feels like, High, Low and Phone labels
  retain what the data means. Forecast temperature is identified as such.
  Loading/failure/expiry retains public reading identity without stale values.
  Known observation age is distinct from a recent transport receipt.
- **Space follows the task:** the compact header stacks weekday/date while
  keeping both horizontal readings. Music's artwork and up to two artist
  lines stay anchored to the bottom; a full-width title grows upward through
  up to three lines with an 8px gap above the footer. Notifications keep their
  source heading and optional bounded body. Summary banners retain the music
  footer and briefly reduce the title area instead of taking over the whole face.
  A heading-only banner can retain two title lines with a gap above that footer.
- **Motion explains priority:** the clock and readings move together as
  context enters or leaves. A changed primary song title defines a track
  change. Late artwork/artist metadata and notification icons repaint in
  place. A notification burst enters once; rapid replacements are coalesced
  for a stable reading interval instead of repeating its entrance.
- **Calm resting states:** transitions are bounded and stop when complete.
  The Animations setting disables Dynamic's local transitions.

A single typography system applies to new and existing installations. Idle
uses an 80px clock, 20px date and 36px reading values; 14px labels explain each
source. Context contracts the clock to 42px while retaining 22px values and
readable 14px symbols. Timeline Peek uses 26px values and 16px symbols.

The legacy Music fallback uses a fixed 24px title and fixed 20px artists. Track length
changes wrapping through up to three title lines per page and two artist lines.
A long received title continues through its remaining pages once, then holds;
it never loops or changes the type size. Native ink measurements showed
that 26px cannot reliably fit three title lines above the footer, so 24px
preserves both readability and the fixed bottom composition. Artwork stays
40px and shares y216 with the bottom of the artist text. A simple fallback tile
holds that space when artwork is absent or transparent, so late covers cannot
move the artist. A pause mark makes the five-second paused-music grace explicit.
The former Larger
text mode is retired, including existing saved choices, and sample previews
have no size selector.

Idle values and labels sit 4px and 6px closer to their symbols than in 0.4.1.
Legacy artist text uses a quieter secondary treatment at 20px.
After native palette rounding, secondary ink falls back to foreground when
muting would lose 4.5:1 contrast. Accent graphics have a 2:1 visibility guard;
provider artwork retains its colours.

Notification sender/title and app identity are separate. The sender is primary,
with an app icon as context, or a quieter app-name line when its icon is absent.
Long app names do not reduce sender text size. A banner preserves the music
footer while its available title lines adjust to the bounded notice heading.
App-only privacy shows app identity while omitting sender and body. Summary
bursts get at most three seconds and actual message previews eight; later
updates never extend the first notice's deadline. Optional Short / Double
vibration defaults to Off, uses the same app filter and respects watch Quiet
Time. It announces a new burst once, not each replacement or redraw.

An optional Quiet Time palette follows the watch's own state and restores the
daytime colours afterward. Both palettes retain the same contrast fallbacks and
geometry; the change does not create another text or layout mode.

The settings page follows the same principles: one page with Appearance,
Content and Connection & help. Safe layout/colour samples are independent of
privacy settings. The Save area describes draft versus last delivery, theme
exploration is reversible, source ownership/recovery is explicit and app filters
are visible individual entries. Read-only OS clock-style queries support
Follow Pebble examples without changing the watchface override; unknown format
is labelled rather than implied. The page uses its own explicit phone light/dark
colours, including controls, independently of chosen watch colours. Sharing a
validated three-colour preset changes only the main palette; privacy and alert
choices are never included.

The face renders source-provided data and recognized semantic symbols. Its
gauges use a validated provider-supplied range, with source-identified rain
probability retaining its 0–100% presentation. Arbitrary percentages never acquire
an invented range. A temperature can use a source
image or a thermometer symbol. Source artwork retains the limitations of the
image actually received.

## Native Timeline priority

Pebble owns the Timeline event panel. Dynamic follows the actual unobstructed
area throughout the native movement, retaining its clock and both readings
above the event. Local context yields its space. This remains true when
Dynamic's own animations are disabled.

The [Unobstructed Area documentation](https://developer.repebble.com/docs/c/User_Interface/UnobstructedArea/)
notes that Peek first moves slightly, then snaps with bounce-back. The
available height can briefly be smaller than the settled height. Native
rendering checks therefore need intermediate movement as well as endpoint
screenshots.

## Assets and verification

Fredoka and Roboto Condensed are Dynamic's font choices. Pebble's built-in
faces use several different type systems. Font sources and SIL Open Font
Licenses accompany Dynamic's generated clock-outline and body-baseline assets.
The optional regeneration tools are pinned in
[`scripts/requirements-font-assets.txt`](../scripts/requirements-font-assets.txt).

The type details include Fredoka temperature/percent units and muted 14px
reading labels. The body font adds Greek, Cyrillic and Latin Extended
Additional coverage for provider text.
Unsupported characters use a visible missing-character glyph.

The native Fredoka renderer uses 4×4 fractional pixel coverage, preserving the
contour geometry and weight while smoothing its edges. It reuses bounded row
buffers without per-frame heap allocation. Source-outline and advance checks
establish the font geometry; native captures separately check the resulting
raster and layout.

Release validation separately checks the C build, font/outline assets and
native captures. Physical-phone delivery and hardware battery life require
separate device checks. See
[the build-specific validation record](VALIDATION.md).

Earlier releases used other presentations: 0.1 bundled Fira Sans Condensed,
and 0.2 used system LECO/Gothic with information bands. Their archived release
artifacts and historical validation remain available.

## Release refinements

Warning ink keeps its amber role only when it has at least 3:1 contrast against
the quantized watch background; otherwise a visible black/white ink wins.
Invisible notification artwork uses the generic icon and app-name fallback.
Music title pages pause under covering system windows and resume the current
page when the face is visible. These refinements preserve type sizes, the fixed
artwork/artist footer, and the one-pass title sequence.
